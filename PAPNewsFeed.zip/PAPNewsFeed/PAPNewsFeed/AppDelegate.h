//
//  AppDelegate.h
//  PAPNewsFeed
//
//  Created by Guest User on 25/11/15.
//  Copyright (c) 2015 EPITA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

