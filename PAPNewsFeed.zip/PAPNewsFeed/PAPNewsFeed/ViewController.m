//
//  ViewController.m
//  PAPNewsFeed
//
//  Created by Guest User on 25/11/15.
//  Copyright (c) 2015 EPITA. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     mystring = [[NSString alloc] initWithFormat:@"hello"];
    _strProperty =[[NSString alloc] initWithFormat:@"hello"];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)changeLabel:(NSString *)string {
    
    _lblTitle.text = string;
}

- (IBAction) doClick:(id)sender{

    [self changeLabel : _strProperty];

}




@end
